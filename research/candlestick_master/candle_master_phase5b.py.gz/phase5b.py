#!/usr/bin/env python3
"""BTC Candlestick Master — Phase 5B precision-rule research.

Purpose
-------
Search for genuinely rare, high-precision BTC swing signals without manufacturing a
90% win rate.  Binance perpetual is the execution/outcome venue; Binance spot and
independent USD venues are used only as causal confirmation.  The script implements
source-derived hypotheses (market structure, Spring/Upthrust, S/R flip, FVG,
rejection blocks, order-block retests, range contraction/expansion, moving-average
location/spacing) as explicit, auditable rules and then subjects them to nested
walk-forward, cost stress, multiple-testing correction and block bootstrap.

The output is research evidence, not a promise of future returns.
"""
from __future__ import annotations

import importlib.util
import itertools
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent
P3_PATH = ROOT / "candle_master_phase3d.py"
spec = importlib.util.spec_from_file_location("phase3d", P3_PATH)
p3 = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(p3)

OUT = ROOT / "output_phase5b"
OUT.mkdir(parents=True, exist_ok=True)

PRIMARY = "binance_perp"
SPOT = "binance_spot"
TF_INFO = {
    "4h": {"rule": "4h", "hours": 4, "pivot_right": 3},
    "1d": {"rule": "1D", "hours": 24, "pivot_right": 2},
}
CONTEXT_TFS = {
    "12h": {"rule": "12h", "hours": 12, "pivot_right": 2},
    "1d": {"rule": "1D", "hours": 24, "pivot_right": 2},
}
# Pre-registered precision configurations.  They are not optimized on the final test.
CONFIGS = {
    "4h": [
        {"config_id": "P05_S10_H6", "target": 0.50, "stop": 1.00, "hold": 6},
        {"config_id": "P05_S125_H6", "target": 0.50, "stop": 1.25, "hold": 6},
        {"config_id": "P075_S10_H8", "target": 0.75, "stop": 1.00, "hold": 8},
        {"config_id": "P10_S10_H8", "target": 1.00, "stop": 1.00, "hold": 8},
    ],
    "1d": [
        {"config_id": "P05_S10_H3", "target": 0.50, "stop": 1.00, "hold": 3},
        {"config_id": "P05_S125_H3", "target": 0.50, "stop": 1.25, "hold": 3},
        {"config_id": "P075_S10_H5", "target": 0.75, "stop": 1.00, "hold": 5},
        {"config_id": "P10_S10_H7", "target": 1.00, "stop": 1.00, "hold": 7},
    ],
}
COST_BPS = [20, 30, 50]
MAIN_COST = 30
FOLDS = [
    {"fold": "WF2023", "train_start": "2020-01-01", "train_end": "2022-01-01", "validation_start": "2022-01-01", "validation_end": "2023-01-01", "test_start": "2023-01-01", "test_end": "2024-01-01"},
    {"fold": "WF2024", "train_start": "2020-01-01", "train_end": "2023-01-01", "validation_start": "2023-01-01", "validation_end": "2024-01-01", "test_start": "2024-01-01", "test_end": "2025-01-01"},
    {"fold": "WF2025", "train_start": "2020-01-01", "train_end": "2024-01-01", "validation_start": "2024-01-01", "validation_end": "2025-01-01", "test_start": "2025-01-01", "test_end": "2026-01-01"},
    {"fold": "WF2026", "train_start": "2020-01-01", "train_end": "2025-01-01", "validation_start": "2025-01-01", "validation_end": "2026-01-01", "test_start": "2026-01-01", "test_end": "2027-01-01"},
]
RNG = np.random.default_rng(20261029)


def utc(value: str | pd.Timestamp) -> pd.Timestamp:
    ts = pd.Timestamp(value)
    return ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")


def safe_div(a: pd.Series | np.ndarray | float, b: pd.Series | np.ndarray | float):
    return np.divide(a, b, out=np.full_like(np.asarray(a, dtype=float), np.nan), where=np.asarray(b) != 0)


def wilson(success: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0:
        return np.nan, np.nan
    p = success / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / den
    return centre - half, centre + half


def bh_adjust(p_values: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(p_values), dtype=float)
    out = np.full(len(p), np.nan)
    valid = np.flatnonzero(np.isfinite(p))
    if len(valid) == 0:
        return out
    order = valid[np.argsort(p[valid])]
    ranked = p[order] * len(order) / np.arange(1, len(order) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    out[order] = np.minimum(ranked, 1.0)
    return out


def max_drawdown_pct(returns_pct: pd.Series) -> float:
    if returns_pct.empty:
        return np.nan
    equity = (1 + returns_pct.fillna(0) / 100).cumprod()
    peak = equity.cummax()
    return float(((equity / peak) - 1).min() * 100)


def profit_factor(values: pd.Series) -> float:
    values = values.dropna().astype(float)
    gp = values[values > 0].sum()
    gl = -values[values <= 0].sum()
    return float(gp / gl) if gl > 0 else (np.inf if gp > 0 else np.nan)


def metrics(frame: pd.DataFrame, cost_bps: int = MAIN_COST) -> dict:
    if frame.empty:
        return {"n": 0}
    col = f"net_{cost_bps}bps_pct"
    values = frame[col].astype(float)
    targets = frame.outcome.eq("target")
    n = len(frame)
    success = int(targets.sum())
    lo, hi = wilson(success, n)
    return {
        "n": int(n),
        "target_rate": float(targets.mean()),
        "target_wilson_low": float(lo),
        "target_wilson_high": float(hi),
        "positive_rate": float((values > 0).mean()),
        "mean_net_pct": float(values.mean()),
        "median_net_pct": float(values.median()),
        "profit_factor": profit_factor(values),
        "max_drawdown_pct": max_drawdown_pct(values),
        "stop_rate": float(frame.outcome.isin(["stop", "ambiguous_as_stop"]).mean()),
        "time_exit_rate": float(frame.outcome.eq("time_exit").mean()),
    }


def causal_structure(x: pd.DataFrame, left: int = 3, right: int = 3) -> pd.DataFrame:
    """Causal pivot/structure state; a pivot is usable only after right bars close."""
    n = len(x)
    highs = x.high.to_numpy(float)
    lows = x.low.to_numpy(float)
    closes = x.close.to_numpy(float)
    atr = x.atr14.to_numpy(float)
    state = np.full(n, "mixed", dtype=object)
    last_high = np.full(n, np.nan)
    last_low = np.full(n, np.nan)
    bull_break = np.zeros(n, bool)
    bear_break = np.zeros(n, bool)
    bull_choch = np.zeros(n, bool)
    bear_choch = np.zeros(n, bool)
    bull_retest = np.zeros(n, bool)
    bear_retest = np.zeros(n, bool)
    high_pivots: list[tuple[int, float]] = []
    low_pivots: list[tuple[int, float]] = []
    last_bull_level = np.nan
    last_bull_bar = -10_000
    last_bear_level = np.nan
    last_bear_bar = -10_000
    prev_state = "mixed"
    for i in range(n):
        pivot_i = i - right
        if pivot_i >= left:
            lo_i = pivot_i - left
            hi_i = i + 1
            if highs[pivot_i] >= np.nanmax(highs[lo_i:hi_i]):
                if not high_pivots or high_pivots[-1][0] != pivot_i:
                    high_pivots.append((pivot_i, highs[pivot_i]))
            if lows[pivot_i] <= np.nanmin(lows[lo_i:hi_i]):
                if not low_pivots or low_pivots[-1][0] != pivot_i:
                    low_pivots.append((pivot_i, lows[pivot_i]))
        lh = high_pivots[-1][1] if high_pivots else np.nan
        ll = low_pivots[-1][1] if low_pivots else np.nan
        last_high[i], last_low[i] = lh, ll
        if len(high_pivots) >= 2 and len(low_pivots) >= 2:
            hh = high_pivots[-1][1] > high_pivots[-2][1]
            hl = low_pivots[-1][1] > low_pivots[-2][1]
            lower_h = high_pivots[-1][1] < high_pivots[-2][1]
            lower_l = low_pivots[-1][1] < low_pivots[-2][1]
            current_state = "bull" if hh and hl else ("bear" if lower_h and lower_l else "mixed")
        else:
            current_state = "mixed"
        state[i] = current_state
        if i > 0 and np.isfinite(lh):
            bull_break[i] = closes[i] > lh and closes[i - 1] <= lh
            if bull_break[i]:
                bull_choch[i] = prev_state == "bear"
                last_bull_level, last_bull_bar = lh, i
        if i > 0 and np.isfinite(ll):
            bear_break[i] = closes[i] < ll and closes[i - 1] >= ll
            if bear_break[i]:
                bear_choch[i] = prev_state == "bull"
                last_bear_level, last_bear_bar = ll, i
        if i > last_bull_bar and i - last_bull_bar <= 4 and np.isfinite(last_bull_level) and np.isfinite(atr[i]):
            bull_retest[i] = lows[i] <= last_bull_level + 0.25 * atr[i] and closes[i] > last_bull_level
        if i > last_bear_bar and i - last_bear_bar <= 4 and np.isfinite(last_bear_level) and np.isfinite(atr[i]):
            bear_retest[i] = highs[i] >= last_bear_level - 0.25 * atr[i] and closes[i] < last_bear_level
        prev_state = current_state
    return pd.DataFrame({
        "structure_state": state,
        "last_swing_high": last_high,
        "last_swing_low": last_low,
        "bull_structure_break": bull_break,
        "bear_structure_break": bear_break,
        "bull_choch": bull_choch,
        "bear_choch": bear_choch,
        "bull_structure_retest": bull_retest,
        "bear_structure_retest": bear_retest,
    }, index=x.index)


def recent_shift_any(conditions: list[pd.Series]) -> pd.Series:
    out = pd.Series(False, index=conditions[0].index)
    for c in conditions:
        out |= c.fillna(False)
    return out


def enrich_precision(raw: pd.DataFrame, hours: int, pivot_right: int) -> pd.DataFrame:
    x = p3.enrich(raw, hours).copy()
    rng = (x.high - x.low).replace(0, np.nan)
    body = (x.close - x.open).abs()
    top = x[["open", "close"]].max(axis=1)
    bottom = x[["open", "close"]].min(axis=1)
    x["body_ratio"] = (body / rng).clip(0, 1).fillna(0)
    x["upper_ratio"] = ((x.high - top) / rng).clip(0, 1).fillna(0)
    x["lower_ratio"] = ((bottom - x.low) / rng).clip(0, 1).fillna(0)
    x["close_location"] = ((x.close - x.low) / rng).clip(0, 1).fillna(0.5)
    x["range_atr"] = rng / x.atr14
    x["atr_relative"] = x.atr_pct / x.atr_pct.rolling(100, min_periods=30).median()
    x["volume_relative"] = x.volume / x.volume.rolling(20, min_periods=10).median().replace(0, np.nan)
    for p in [5, 10, 20, 60, 112, 224, 448, 896]:
        x[f"ma{p}_s5"] = (x[f"ma{p}"] / x[f"ma{p}"].shift(5) - 1) * 100
        x[f"ma{p}_accel"] = x[f"ma{p}_s5"] - x[f"ma{p}_s5"].shift(5)
    slopes = pd.concat([(x[f"ma{p}_s20"] > 0).rename(str(p)) for p in [5, 10, 20, 60, 112, 224, 448, 896]], axis=1)
    x["rising_count8"] = slopes.sum(axis=1)
    long_mas = x[["ma112", "ma224", "ma448", "ma896"]]
    x["long_ma_spread_atr"] = (long_mas.max(axis=1) - long_mas.min(axis=1)) / x.atr14
    x["long_ma_compressed"] = x.long_ma_spread_atr < 1.5

    # Causal market structure.
    structure = causal_structure(x, left=3, right=pivot_right)
    x = pd.concat([x, structure], axis=1)

    # S/R flip and retest: breakout/breakdown in one of the previous four bars.
    prior_hi20 = x.high.shift(1).rolling(20, min_periods=20).max()
    prior_lo20 = x.low.shift(1).rolling(20, min_periods=20).min()
    bull_breakout = x.close > prior_hi20 + 0.05 * x.atr14
    bear_breakdown = x.close < prior_lo20 - 0.05 * x.atr14
    bull_sr = []
    bear_sr = []
    for lag in range(1, 5):
        level_h = prior_hi20.shift(lag)
        level_l = prior_lo20.shift(lag)
        bull_sr.append(bull_breakout.shift(lag).fillna(False) & (x.low <= level_h + 0.25 * x.atr14) & (x.close > level_h))
        bear_sr.append(bear_breakdown.shift(lag).fillna(False) & (x.high >= level_l - 0.25 * x.atr14) & (x.close < level_l))
    x["bull_sr_flip_retest"] = recent_shift_any(bull_sr)
    x["bear_sr_flip_retest"] = recent_shift_any(bear_sr)

    # Fair value gap creation and later midpoint rejection, using only completed bars.
    bull_fvg_created = x.low > x.high.shift(2) + 0.05 * x.atr14
    bear_fvg_created = x.high < x.low.shift(2) - 0.05 * x.atr14
    bull_fvg_retests = []
    bear_fvg_retests = []
    for lag in range(1, 7):
        bull_lower = x.high.shift(lag + 2)
        bull_upper = x.low.shift(lag)
        bull_mid = (bull_lower + bull_upper) / 2
        bull_fvg_retests.append(
            bull_fvg_created.shift(lag).fillna(False)
            & (x.low <= bull_upper)
            & (x.close >= bull_mid)
            & (x.close > bull_lower)
        )
        bear_upper = x.low.shift(lag + 2)
        bear_lower = x.high.shift(lag)
        bear_mid = (bear_upper + bear_lower) / 2
        bear_fvg_retests.append(
            bear_fvg_created.shift(lag).fillna(False)
            & (x.high >= bear_lower)
            & (x.close <= bear_mid)
            & (x.close < bear_upper)
        )
    x["bull_fvg_rejection"] = recent_shift_any(bull_fvg_retests)
    x["bear_fvg_rejection"] = recent_shift_any(bear_fvg_retests)

    # Rejection block at a long moving average or confirmed swing point.
    ma_distance = pd.concat([((x.close - x[f"ma{p}"]).abs() / x.atr14) for p in [112, 224, 448, 896]], axis=1).min(axis=1)
    swing_low_dist = (x.close - x.last_swing_low).abs() / x.atr14
    swing_high_dist = (x.close - x.last_swing_high).abs() / x.atr14
    x["bull_ma_rejection"] = (x.lower_ratio >= 0.45) & (x.close_location >= 0.65) & ((ma_distance <= 0.35) | (swing_low_dist <= 0.35))
    x["bear_ma_rejection"] = (x.upper_ratio >= 0.45) & (x.close_location <= 0.35) & ((ma_distance <= 0.35) | (swing_high_dist <= 0.35))

    # Last opposite candle before displacement, followed by a causal retest.
    bull_disp = (x.close > x.open) & (body >= 1.25 * x.atr14) & (x.close > x.high.shift(1))
    bear_disp = (x.close < x.open) & (body >= 1.25 * x.atr14) & (x.close < x.low.shift(1))
    bull_ob = []
    bear_ob = []
    for lag in range(1, 9):
        ob_open = x.open.shift(lag + 1)
        ob_close = x.close.shift(lag + 1)
        ob_low = x.low.shift(lag + 1)
        ob_high = x.high.shift(lag + 1)
        bull_ob.append(
            bull_disp.shift(lag).fillna(False)
            & (ob_close < ob_open)
            & (x.low <= ob_open)
            & (x.close > (ob_open + ob_close) / 2)
            & (x.close > ob_low)
        )
        bear_ob.append(
            bear_disp.shift(lag).fillna(False)
            & (ob_close > ob_open)
            & (x.high >= ob_open)
            & (x.close < (ob_open + ob_close) / 2)
            & (x.close < ob_high)
        )
    x["bull_ob_retest"] = recent_shift_any(bull_ob)
    x["bear_ob_retest"] = recent_shift_any(bear_ob)

    # Range contraction and expansion.
    prior_compressed = x.range_atr.shift(1).rolling(6, min_periods=6).mean() < 0.75
    x["bull_compression_expansion"] = prior_compressed & (x.range_atr >= 1.25) & (x.close_location >= 0.75) & (x.close > x.open)
    x["bear_compression_expansion"] = prior_compressed & (x.range_atr >= 1.25) & (x.close_location <= 0.25) & (x.close < x.open)

    # Approximate three-tap structure with a confirmed break away from repeated range edge.
    rolling_low = x.low.rolling(20, min_periods=20).min()
    rolling_high = x.high.rolling(20, min_periods=20).max()
    low_touch = ((x.low - rolling_low).abs() <= 0.25 * x.atr14).astype(int)
    high_touch = ((x.high - rolling_high).abs() <= 0.25 * x.atr14).astype(int)
    x["bull_three_tap_break"] = (low_touch.rolling(20, min_periods=20).sum() >= 3) & (x.close > x.high.shift(1)) & (x.close_location >= 0.70)
    x["bear_three_tap_break"] = (high_touch.rolling(20, min_periods=20).sum() >= 3) & (x.close < x.low.shift(1)) & (x.close_location <= 0.30)

    # Side-specific next long MA distance.
    ma_cols = ["ma112", "ma224", "ma448", "ma896"]
    above_dist = pd.concat([((x[c] - x.close) / x.atr14).where(x[c] > x.close) for c in ma_cols], axis=1)
    below_dist = pd.concat([((x.close - x[c]) / x.atr14).where(x[c] < x.close) for c in ma_cols], axis=1)
    x["next_ma_gap_long"] = above_dist.min(axis=1)
    x["next_ma_gap_short"] = below_dist.min(axis=1)

    # A compact directional bias used only as a context feature.
    x["bull_bias_score"] = (
        (x.above_count >= 5).astype(int)
        + (x.rising_count8 >= 5).astype(int)
        + x.structure_state.eq("bull").astype(int)
        + x.long_bull_stack.astype(int)
    )
    x["bear_bias_score"] = (
        (x.above_count <= 3).astype(int)
        + (x.rising_count8 <= 3).astype(int)
        + x.structure_state.eq("bear").astype(int)
        + x.long_bear_stack.astype(int)
    )
    return x


def base_masks(x: pd.DataFrame, tf: str) -> dict[str, tuple[pd.Series, str]]:
    base = p3.build_rules(x, tf)
    keep = {
        "low_sweep_rsi30_40", "high_sweep_rsi60_70",
        "spring_confirm", "upthrust_confirm",
        "bull_3x_upper_half_hold", "bear_3x_lower_half_hold",
        "bull_3x_break_high", "bear_3x_break_low",
    }
    out = {name: value for name, value in base.items() if name in keep}
    out.update({
        "bull_sr_flip_retest": (x.bull_sr_flip_retest, "long"),
        "bear_sr_flip_retest": (x.bear_sr_flip_retest, "short"),
        "bull_choch_retest": (x.bull_structure_retest & (x.bull_choch.shift(1).rolling(5, min_periods=1).max().fillna(0).astype(bool)), "long"),
        "bear_choch_retest": (x.bear_structure_retest & (x.bear_choch.shift(1).rolling(5, min_periods=1).max().fillna(0).astype(bool)), "short"),
        "bull_fvg_rejection": (x.bull_fvg_rejection, "long"),
        "bear_fvg_rejection": (x.bear_fvg_rejection, "short"),
        "bull_ma_rejection": (x.bull_ma_rejection, "long"),
        "bear_ma_rejection": (x.bear_ma_rejection, "short"),
        "bull_ob_retest": (x.bull_ob_retest, "long"),
        "bear_ob_retest": (x.bear_ob_retest, "short"),
        "bull_compression_expansion": (x.bull_compression_expansion, "long"),
        "bear_compression_expansion": (x.bear_compression_expansion, "short"),
        "bull_three_tap_break": (x.bull_three_tap_break, "long"),
        "bear_three_tap_break": (x.bear_three_tap_break, "short"),
    })
    return {k: (v[0].fillna(False).astype(bool), v[1]) for k, v in out.items()}


def completed_context(base: pd.DataFrame, higher: pd.DataFrame, prefix: str, columns: list[str]) -> pd.DataFrame:
    left = base.reset_index().rename(columns={base.index.name or "index": "bar_open"}).sort_values("signal_time")
    right = higher.reset_index().rename(columns={higher.index.name or "index": "htf_bar_open"}).sort_values("signal_time")
    right = right[["signal_time"] + columns].rename(columns={"signal_time": "available_time", **{c: f"{prefix}_{c}" for c in columns}})
    merged = pd.merge_asof(left, right.sort_values("available_time"), left_on="signal_time", right_on="available_time", direction="backward")
    merged = merged.drop(columns=["available_time"]).set_index("bar_open")
    return merged


def build_frames(venues: dict[str, pd.DataFrame]) -> dict[str, dict[str, pd.DataFrame]]:
    frames: dict[str, dict[str, pd.DataFrame]] = {}
    for venue, hourly in venues.items():
        tf_frames: dict[str, pd.DataFrame] = {}
        for tf, info in {**TF_INFO, "12h": CONTEXT_TFS["12h"]}.items():
            raw = p3.resample_ohlcv(hourly, info["rule"])
            tf_frames[tf] = enrich_precision(raw, info["hours"], info["pivot_right"])
        # Attach completed 12h and daily context to 4h.
        context_cols = ["bull_bias_score", "bear_bias_score", "structure_state", "above_count", "rising_count8", "long_bull_stack", "long_bear_stack", "rsi14", "atr_relative"]
        four = completed_context(tf_frames["4h"], tf_frames["12h"], "h12", context_cols)
        four = completed_context(four, tf_frames["1d"], "d1", context_cols)
        tf_frames["4h"] = four
        frames[venue] = tf_frames
    return frames


def side_context_flags(row: pd.Series, side: str, tf: str) -> dict[str, bool]:
    long_side = side == "long"
    prefix = "bull" if long_side else "bear"
    next_gap = row.get("next_ma_gap_long" if long_side else "next_ma_gap_short", np.nan)
    rsi = row.get("rsi14", np.nan)
    flags = {
        "f_self_structure": row.get("structure_state") == ("bull" if long_side else "bear"),
        "f_structure_break": bool(row.get(f"{prefix}_structure_break", False) or row.get(f"{prefix}_choch", False)),
        "f_sr_flip": bool(row.get(f"{prefix}_sr_flip_retest", False)),
        "f_fvg_hold": bool(row.get(f"{prefix}_fvg_rejection", False)),
        "f_ma_rejection": bool(row.get(f"{prefix}_ma_rejection", False)),
        "f_ob_retest": bool(row.get(f"{prefix}_ob_retest", False)),
        "f_compression_expansion": bool(row.get(f"{prefix}_compression_expansion", False)),
        "f_three_tap": bool(row.get(f"{prefix}_three_tap_break", False)),
        "f_above_strong": bool(row.get("above_count", 0) >= 6 if long_side else row.get("above_count", 8) <= 2),
        "f_slope_strong": bool(row.get("rising_count8", 0) >= 6 if long_side else row.get("rising_count8", 8) <= 2),
        "f_long_stack": bool(row.get("long_bull_stack", False) if long_side else row.get("long_bear_stack", False)),
        "f_long_ma_compressed": bool(row.get("long_ma_compressed", False)),
        "f_next_gap_lt1": bool(np.isfinite(next_gap) and next_gap < 1.0),
        "f_next_gap_lt2": bool(np.isfinite(next_gap) and next_gap < 2.0),
        "f_rsi_reversal_zone": bool(30 <= rsi < 55 if long_side else 45 < rsi <= 70),
        "f_atr_normal": bool(0.75 <= row.get("atr_relative", np.nan) <= 1.35),
        "f_atr_expanding": bool(row.get("atr_relative", 0) > 1.10),
        "f_volume_expanding": bool(row.get("volume_relative", 0) >= 1.20),
        "f_body_confirm": bool(row.get("close_location", 0) >= 0.70 if long_side else row.get("close_location", 1) <= 0.30),
    }
    if tf == "4h":
        flags.update({
            "f_h12_align": bool(row.get("h12_bull_bias_score", 0) >= 2 if long_side else row.get("h12_bear_bias_score", 0) >= 2),
            "f_d1_align": bool(row.get("d1_bull_bias_score", 0) >= 2 if long_side else row.get("d1_bear_bias_score", 0) >= 2),
            "f_d1_structure": row.get("d1_structure_state") == ("bull" if long_side else "bear"),
        })
    else:
        flags.update({"f_h12_align": False, "f_d1_align": True, "f_d1_structure": flags["f_self_structure"]})
    return flags


def kst_zone(ts: pd.Timestamp) -> str:
    return p3.kill_zone_kst(ts)


def build_event_table(frames: dict[str, dict[str, pd.DataFrame]]) -> tuple[pd.DataFrame, dict[str, dict[str, dict[str, tuple[pd.Series, str]]]]]:
    masks: dict[str, dict[str, dict[str, tuple[pd.Series, str]]]] = {}
    for venue, tf_frames in frames.items():
        masks[venue] = {tf: base_masks(tf_frames[tf], tf) for tf in TF_INFO}

    rows: list[dict] = []
    primary_frames = frames[PRIMARY]
    for tf in TF_INFO:
        x = primary_frames[tf]
        primary_masks = masks[PRIMARY][tf]
        spot_x = frames[SPOT][tf]
        # Signal-time indexed lookup tables for all venues.
        venue_signal_frames = {
            venue: frame[tf].reset_index().set_index("signal_time")
            for venue, frame in frames.items()
        }
        venue_mask_frames: dict[str, pd.DataFrame] = {}
        for venue in frames:
            mdf = pd.DataFrame(index=frames[venue][tf].signal_time)
            for name, (mask, side) in masks[venue][tf].items():
                mdf[name] = mask.to_numpy(bool)
            venue_mask_frames[venue] = mdf

        for side in ["long", "short"]:
            names = [name for name, (_, s) in primary_masks.items() if s == side]
            if not names:
                continue
            mask_matrix = pd.concat([primary_masks[name][0].rename(name) for name in names], axis=1)
            any_mask = mask_matrix.any(axis=1)
            for i in np.flatnonzero(any_mask.to_numpy()):
                signal_time = pd.Timestamp(x.signal_time.iloc[i])
                active = [name for name in names if bool(mask_matrix[name].iloc[i])]
                row = x.iloc[i]
                event = {
                    "venue": PRIMARY,
                    "timeframe": tf,
                    "side": side,
                    "signal_time": signal_time,
                    "bar_index": int(i),
                    "entry_time": x.index[i + 1] if i + 1 < len(x) else pd.NaT,
                    "active_patterns": ",".join(sorted(active)),
                    "base_count": len(active),
                    "rsi14": float(row.rsi14) if np.isfinite(row.rsi14) else np.nan,
                    "atr_pct": float(row.atr_pct) if np.isfinite(row.atr_pct) else np.nan,
                    "next_ma_gap": float(row.get("next_ma_gap_long" if side == "long" else "next_ma_gap_short", np.nan)),
                    "kill_zone": kst_zone(signal_time),
                    "year": signal_time.year,
                    "month": signal_time.to_period("M").strftime("%Y-%m"),
                }
                for name in sorted({n for m in masks.values() for d in m.values() for n in d}):
                    event[f"b_{name}"] = name in active
                event.update(side_context_flags(row, side, tf))

                # Exact causal confirmation from spot and independent venues at the same close.
                consensus = 0
                spot_same = False
                for venue, mdf in venue_mask_frames.items():
                    if signal_time not in mdf.index:
                        continue
                    same = any(name in mdf.columns and bool(mdf.at[signal_time, name]) for name in active)
                    consensus += int(same)
                    if venue == SPOT:
                        spot_same = same
                event["f_spot_same_base"] = spot_same
                event["f_consensus_ge2"] = consensus >= 2
                event["f_consensus_ge3"] = consensus >= 3
                event["f_consensus_ge4"] = consensus >= 4
                event["consensus_count"] = consensus

                # Spot directional context at exactly the same completed candle.
                if signal_time in venue_signal_frames[SPOT].index:
                    sr = venue_signal_frames[SPOT].loc[signal_time]
                    if isinstance(sr, pd.DataFrame):
                        sr = sr.iloc[-1]
                    long_side = side == "long"
                    event["f_spot_bias_align"] = bool(sr.get("bull_bias_score", 0) >= 2 if long_side else sr.get("bear_bias_score", 0) >= 2)
                    event["f_spot_structure_align"] = sr.get("structure_state") == ("bull" if long_side else "bear")
                    event["f_spot_ma_align"] = bool(sr.get("above_count", 0) >= 6 if long_side else sr.get("above_count", 8) <= 2)
                    spot_close = float(sr.close)
                    perp_close = float(row.close)
                    basis_bps = (perp_close / spot_close - 1) * 10000 if spot_close else np.nan
                    spot_range = float(sr.high - sr.low)
                    perp_range = float(row.high - row.low)
                    range_ratio = perp_range / spot_range if spot_range > 0 else np.nan
                    event["basis_bps"] = basis_bps
                    event["range_ratio"] = range_ratio
                    event["f_basis_normal"] = bool(np.isfinite(basis_bps) and abs(basis_bps) <= 15)
                    event["f_range_ratio_normal"] = bool(np.isfinite(range_ratio) and 0.75 <= range_ratio <= 1.35)
                else:
                    event.update({
                        "f_spot_bias_align": False, "f_spot_structure_align": False,
                        "f_spot_ma_align": False, "basis_bps": np.nan,
                        "range_ratio": np.nan, "f_basis_normal": False,
                        "f_range_ratio_normal": False,
                    })
                event["f_kz_asia"] = event["kill_zone"] == "asia_kz"
                event["f_kz_london"] = event["kill_zone"] == "london_kz"
                event["f_kz_newyork"] = event["kill_zone"] == "newyork_kz"
                event["f_kz_other"] = event["kill_zone"] == "other"
                rows.append(event)
    events = pd.DataFrame(rows).sort_values(["signal_time", "timeframe", "side"]).reset_index(drop=True)
    events["event_id"] = np.arange(len(events), dtype=int)
    bool_cols = [c for c in events.columns if c.startswith(("b_", "f_"))]
    events[bool_cols] = events[bool_cols].fillna(False).astype(bool)
    return events, masks


def simulate_event(x: pd.DataFrame, bar_index: int, side: str, target_mult: float, stop_mult: float, hold: int) -> dict:
    i = int(bar_index)
    if i + 1 + hold >= len(x) or not np.isfinite(x.atr14.iloc[i]):
        return {"valid": False}
    entry_i = i + 1
    entry = float(x.open.iloc[entry_i])
    atr = float(x.atr14.iloc[i])
    if entry <= 0 or atr <= 0 or not np.isfinite(entry):
        return {"valid": False}
    target = entry + target_mult * atr if side == "long" else entry - target_mult * atr
    stop = entry - stop_mult * atr if side == "long" else entry + stop_mult * atr
    outcome = "time_exit"
    exit_i = entry_i + hold
    exit_price = float(x.close.iloc[exit_i])
    for j in range(entry_i, entry_i + hold + 1):
        hi, lo = float(x.high.iloc[j]), float(x.low.iloc[j])
        hit_t = hi >= target if side == "long" else lo <= target
        hit_s = lo <= stop if side == "long" else hi >= stop
        if hit_t and hit_s:
            outcome, exit_i, exit_price = "ambiguous_as_stop", j, stop
            break
        if hit_s:
            outcome, exit_i, exit_price = "stop", j, stop
            break
        if hit_t:
            outcome, exit_i, exit_price = "target", j, target
            break
    gross = ((exit_price / entry - 1) if side == "long" else (entry / exit_price - 1)) * 100
    result = {
        "valid": True,
        "entry": entry,
        "target_price": target,
        "stop_price": stop,
        "exit": exit_price,
        "exit_time": x.index[exit_i],
        "outcome": outcome,
        "holding_bars": int(exit_i - entry_i + 1),
        "gross_pct": gross,
    }
    for cost in COST_BPS:
        result[f"net_{cost}bps_pct"] = gross - cost / 100
    return result


def build_outcomes(events: pd.DataFrame, primary_frames: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows: list[dict] = []
    for tf, configs in CONFIGS.items():
        x = primary_frames[tf]
        z = events[events.timeframe == tf]
        for cfg in configs:
            for r in z.itertuples(index=False):
                sim = simulate_event(x, r.bar_index, r.side, cfg["target"], cfg["stop"], cfg["hold"])
                if sim.get("valid"):
                    rows.append({
                        "event_id": int(r.event_id), "timeframe": tf, "side": r.side,
                        "signal_time": r.signal_time, "config_id": cfg["config_id"],
                        "target_mult": cfg["target"], "stop_mult": cfg["stop"],
                        "max_hold": cfg["hold"], **sim,
                    })
    return pd.DataFrame(rows)


def period_mask(times: pd.Series, start: str, end: str) -> np.ndarray:
    t = pd.to_datetime(times, utc=True)
    return ((t >= utc(start)) & (t < utc(end))).to_numpy()


def rule_mask(frame: pd.DataFrame, conditions: tuple[str, ...]) -> np.ndarray:
    if not conditions:
        return np.ones(len(frame), dtype=bool)
    out = np.ones(len(frame), dtype=bool)
    for c in conditions:
        out &= frame[c].to_numpy(bool)
    return out


def score_rule(frame: pd.DataFrame, mask: np.ndarray, cost: int = MAIN_COST) -> dict:
    """Fast rule metrics used during mining; path-dependent drawdown is deferred."""
    idx = np.flatnonzero(mask)
    n = len(idx)
    if n == 0:
        return {"n": 0}
    target = frame.outcome.eq("target").to_numpy()[idx]
    values = frame[f"net_{cost}bps_pct"].to_numpy(float)[idx]
    success = int(target.sum())
    lo, hi = wilson(success, n)
    gp = values[values > 0].sum()
    gl = -values[values <= 0].sum()
    pf = float(gp / gl) if gl > 0 else (np.inf if gp > 0 else np.nan)
    return {
        "n": int(n),
        "target_rate": float(success / n),
        "target_wilson_low": float(lo),
        "target_wilson_high": float(hi),
        "positive_rate": float((values > 0).mean()),
        "mean_net_pct": float(values.mean()),
        "median_net_pct": float(np.median(values)),
        "profit_factor": pf,
        "max_drawdown_pct": np.nan,
        "stop_rate": float(frame.outcome.isin(["stop", "ambiguous_as_stop"]).to_numpy()[idx].mean()),
        "time_exit_rate": float(frame.outcome.eq("time_exit").to_numpy()[idx].mean()),
    }


def candidate_p_value(success: int, n: int, baseline: float) -> float:
    if n <= 0 or not np.isfinite(baseline):
        return np.nan
    return float(stats.binomtest(success, n, p=float(np.clip(baseline, 1e-6, 1 - 1e-6)), alternative="greater").pvalue)


def beam_candidates(train: pd.DataFrame, tf: str, side: str) -> list[tuple[str, ...]]:
    """Generate interpretable conjunctions from training data only."""
    base_cols = [c for c in train.columns if c.startswith("b_") and train[c].any()]
    context_cols = [c for c in train.columns if c.startswith("f_") and train[c].any()]
    min_train = 35 if tf == "4h" else 10
    baseline = float(train.outcome.eq("target").mean())
    candidates: dict[tuple[str, ...], float] = {}
    current: list[tuple[str, ...]] = [(b,) for b in base_cols]
    seen = set(current)
    for depth in range(1, 4):
        scored: list[tuple[float, tuple[str, ...]]] = []
        for conditions in current:
            m = score_rule(train, rule_mask(train, conditions), MAIN_COST)
            if m.get("n", 0) < min_train:
                continue
            # Depth one is retained for extension even when weak; deeper levels need an edge.
            if depth > 1 and (m["target_rate"] < baseline + 0.07 or m["mean_net_pct"] <= 0):
                continue
            quality = m["target_wilson_low"] + 0.10 * max(m["mean_net_pct"], -1) + 0.01 * math.log1p(m["n"])
            candidates[conditions] = quality
            scored.append((quality, conditions))
        scored.sort(reverse=True)
        beam = [c for _, c in scored[:120]]
        if depth == 3 or not beam:
            break
        next_level: set[tuple[str, ...]] = set()
        for conditions in beam:
            for feature in context_cols:
                if feature in conditions:
                    continue
                new = tuple(sorted((*conditions, feature)))
                if new not in seen:
                    seen.add(new)
                    next_level.add(new)
        current = list(next_level)
    return list(candidates)


def select_rules_for_fold(merged: pd.DataFrame, fold: dict, tf: str, side: str, config_id: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    z = merged[(merged.timeframe == tf) & (merged.side == side) & (merged.config_id == config_id)].copy()
    train = z[period_mask(z.signal_time, fold["train_start"], fold["train_end"])].copy()
    validation = z[period_mask(z.signal_time, fold["validation_start"], fold["validation_end"])].copy()
    test = z[period_mask(z.signal_time, fold["test_start"], fold["test_end"])].copy()
    if train.empty or validation.empty or test.empty:
        return pd.DataFrame(), pd.DataFrame()
    candidates = beam_candidates(train, tf, side)
    baseline_train = float(train.outcome.eq("target").mean())
    baseline_val = float(validation.outcome.eq("target").mean())
    rows = []
    min_val = 9 if tf == "4h" else 3
    for conditions in candidates:
        mt = score_rule(train, rule_mask(train, conditions), MAIN_COST)
        mv = score_rule(validation, rule_mask(validation, conditions), MAIN_COST)
        if mv.get("n", 0) < min_val:
            continue
        success = int(round(mv["target_rate"] * mv["n"]))
        p = candidate_p_value(success, mv["n"], baseline_val)
        rows.append({
            "fold": fold["fold"], "timeframe": tf, "side": side, "config_id": config_id,
            "conditions": " & ".join(conditions), "condition_count": len(conditions),
            "train_baseline_target_rate": baseline_train,
            "validation_baseline_target_rate": baseline_val,
            **{f"train_{k}": v for k, v in mt.items()},
            **{f"validation_{k}": v for k, v in mv.items()},
            "validation_p_value": p,
        })
    audit = pd.DataFrame(rows)
    if audit.empty:
        return pd.DataFrame(), audit
    audit["validation_bh_q"] = bh_adjust(audit.validation_p_value)
    audit["selection_score"] = (
        audit[["train_target_wilson_low", "validation_target_wilson_low"]].min(axis=1)
        + 0.12 * audit[["train_mean_net_pct", "validation_mean_net_pct"]].min(axis=1)
        + 0.01 * np.log1p(audit.validation_n)
        - 0.015 * (audit.condition_count - 1)
    )
    # Selection is deliberately strict but does not demand 90%; final test decides that.
    eligible = audit[
        (audit.train_target_rate >= 0.72)
        & (audit.validation_target_rate >= 0.70)
        & (audit.train_mean_net_pct > 0)
        & (audit.validation_mean_net_pct > 0)
        & (audit.validation_profit_factor >= 1.15)
        & (audit.validation_bh_q <= 0.25)
    ].copy()
    if eligible.empty:
        # Preserve a small diagnostic shortlist; it is not promoted.
        eligible = audit.sort_values(["selection_score", "validation_n"], ascending=False).head(2).copy()
        eligible["diagnostic_only"] = True
    else:
        eligible = eligible.sort_values(["selection_score", "validation_n"], ascending=False).head(5).copy()
        eligible["diagnostic_only"] = False

    selected_test_rows = []
    for rank, r in enumerate(eligible.itertuples(index=False), start=1):
        conditions = tuple(str(r.conditions).split(" & "))
        mask = rule_mask(test, conditions)
        q = test.loc[mask].copy()
        if q.empty:
            continue
        q["fold"] = fold["fold"]
        q["rule_conditions"] = r.conditions
        q["rule_rank"] = rank
        q["selection_score"] = r.selection_score
        q["validation_target_rate"] = r.validation_target_rate
        q["validation_n"] = r.validation_n
        q["validation_bh_q"] = r.validation_bh_q
        q["diagnostic_only"] = r.diagnostic_only
        selected_test_rows.append(q)
    selected_test = pd.concat(selected_test_rows, ignore_index=True) if selected_test_rows else pd.DataFrame()
    return selected_test, audit


def strict_portfolio(selected: pd.DataFrame) -> pd.DataFrame:
    if selected.empty:
        return selected
    z = selected[~selected.diagnostic_only].copy()
    if z.empty:
        return z
    # If several rules select the same event, keep the strongest validation score.
    z = z.sort_values(["signal_time", "selection_score", "validation_target_rate", "validation_n"], ascending=[True, False, False, False])
    z = z.drop_duplicates(["event_id", "config_id", "fold"], keep="first")
    # Across configurations/rules, allow only one live position at a time.
    kept = []
    busy_until = pd.Timestamp.min.tz_localize("UTC")
    for _, r in z.iterrows():
        st = pd.to_datetime(r.signal_time, utc=True)
        if st < busy_until:
            continue
        same_time = z[z.signal_time == r.signal_time]
        best = same_time.sort_values(["selection_score", "validation_target_rate", "validation_n"], ascending=False).iloc[0]
        if int(best.event_id) != int(r.event_id) or str(best.config_id) != str(r.config_id):
            continue
        kept.append(r)
        busy_until = pd.to_datetime(r.exit_time, utc=True)
    return pd.DataFrame(kept)


def block_bootstrap(frame: pd.DataFrame, cost: int, iterations: int = 10000) -> dict:
    if frame.empty:
        return {}
    z = frame.copy()
    z["month_block"] = pd.to_datetime(z.signal_time, utc=True).dt.to_period("M").astype(str)
    blocks = [g for _, g in z.groupby("month_block")]
    if not blocks:
        return {}
    target_rates = []
    means = []
    for _ in range(iterations):
        sample = pd.concat([blocks[i] for i in RNG.integers(0, len(blocks), len(blocks))], ignore_index=True)
        target_rates.append(float(sample.outcome.eq("target").mean()))
        means.append(float(sample[f"net_{cost}bps_pct"].mean()))
    return {
        "target_rate_boot_low": float(np.quantile(target_rates, 0.025)),
        "target_rate_boot_high": float(np.quantile(target_rates, 0.975)),
        "mean_net_boot_low": float(np.quantile(means, 0.025)),
        "mean_net_boot_high": float(np.quantile(means, 0.975)),
    }


def precision_frontier(selected: pd.DataFrame) -> pd.DataFrame:
    if selected.empty:
        return pd.DataFrame()
    rows = []
    # Rule-level test performance, with exact rule/config canonicalization.
    for keys, g in selected.groupby(["timeframe", "side", "config_id", "rule_conditions", "diagnostic_only"]):
        m20, m30, m50 = metrics(g, 20), metrics(g, 30), metrics(g, 50)
        years = []
        for year, gy in g.groupby(pd.to_datetime(g.signal_time, utc=True).dt.year):
            years.append({"year": int(year), **metrics(gy, 30)})
        rows.append({
            "timeframe": keys[0], "side": keys[1], "config_id": keys[2],
            "rule_conditions": keys[3], "diagnostic_only": keys[4],
            **{f"c20_{k}": v for k, v in m20.items()},
            **{f"c30_{k}": v for k, v in m30.items()},
            **{f"c50_{k}": v for k, v in m50.items()},
            "years_json": json.dumps(years, ensure_ascii=False),
        })
    return pd.DataFrame(rows).sort_values(["c30_target_rate", "c30_n"], ascending=False)


def aplus_gate(frontier: pd.DataFrame) -> pd.DataFrame:
    if frontier.empty:
        return frontier
    rows = []
    for r in frontier.itertuples(index=False):
        years = json.loads(r.years_json)
        active_years = [y for y in years if y.get("n", 0) >= 3]
        min_year_target = min((y.get("target_rate", np.nan) for y in active_years), default=np.nan)
        min_year_mean = min((y.get("mean_net_pct", np.nan) for y in active_years), default=np.nan)
        strict = (
            not bool(r.diagnostic_only)
            and r.c30_n >= (30 if r.timeframe == "4h" else 15)
            and r.c30_target_rate >= 0.90
            and r.c30_target_wilson_low >= 0.75
            and r.c50_mean_net_pct > 0
            and r.c50_profit_factor >= 1.50
            and len(active_years) >= 2
            and min_year_target >= 0.70
            and min_year_mean > 0
        )
        sparse_90 = r.c30_n >= 5 and r.c30_target_rate >= 0.90
        rows.append({
            **r._asdict(),
            "active_years": len(active_years),
            "min_year_target_rate": min_year_target,
            "min_year_mean_net_pct": min_year_mean,
            "aplus_pass": strict,
            "sparse_observed_90": sparse_90 and not strict,
        })
    return pd.DataFrame(rows).sort_values(["aplus_pass", "c30_target_rate", "c30_n"], ascending=[False, False, False])


def support_precision_table(gate: pd.DataFrame) -> pd.DataFrame:
    if gate.empty:
        return pd.DataFrame()
    rows = []
    for minimum in [5, 10, 15, 20, 30, 50, 100]:
        z = gate[(gate.c30_n >= minimum) & ~gate.diagnostic_only]
        if z.empty:
            rows.append({"minimum_rule_test_n": minimum, "qualifying_rules": 0})
            continue
        best = z.sort_values(["c30_target_rate", "c30_n"], ascending=False).iloc[0]
        rows.append({
            "minimum_rule_test_n": minimum,
            "qualifying_rules": len(z),
            "best_target_rate": best.c30_target_rate,
            "best_wilson_low": best.c30_target_wilson_low,
            "best_n": best.c30_n,
            "best_mean_net_30bps": best.c30_mean_net_pct,
            "best_mean_net_50bps": best.c50_mean_net_pct,
            "best_timeframe": best.timeframe,
            "best_side": best.side,
            "best_config_id": best.config_id,
            "best_conditions": best.rule_conditions,
        })
    return pd.DataFrame(rows)


def write_report(metadata: dict, portfolio: pd.DataFrame, gate: pd.DataFrame, support_table: pd.DataFrame, audits: pd.DataFrame) -> None:
    pm20, pm30, pm50 = metrics(portfolio, 20), metrics(portfolio, 30), metrics(portfolio, 50)
    boot = block_bootstrap(portfolio, 30, iterations=10000) if not portfolio.empty else {}
    pass_rows = gate[gate.aplus_pass] if not gate.empty else pd.DataFrame()
    sparse_rows = gate[gate.sparse_observed_90] if not gate.empty else pd.DataFrame()
    lines = [
        "# BTC Candlestick Master — Phase 5B Precision Audit",
        "",
        "## Decision",
        "",
        ("At least one historical rule passed the strict A+ gate." if not pass_rows.empty else "No historical rule passed the strict 90% A+ promotion gate."),
        "",
        "The result is deliberately conservative. Binance perpetual is the execution venue; Binance spot, Coinbase and Bitstamp are causal confirmation only. A 90% observed rate with a tiny sample is listed separately and is never promoted.",
        "",
        "## Research design",
        "",
        "- Base timeframes: 4h and 1d only.",
        "- 1h is excluded from direction generation.",
        "- Entry: next Binance-perpetual bar open.",
        "- Same-bar target and stop: stop.",
        "- Main selection cost: 30 bps round trip; stress: 20 and 50 bps.",
        "- Pre-registered target/stop/holding configurations; no final-test tuning.",
        "- Expanding walk-forward: train, one-year validation, following-year test.",
        "- Candidate conjunctions generated from training only.",
        "- Validation p-values adjusted with Benjamini-Hochberg correction.",
        "- Strict portfolio removes overlapping positions.",
        "",
        "## Strict portfolio",
        "",
        pd.DataFrame([{"cost_bps": 20, **pm20}, {"cost_bps": 30, **pm30}, {"cost_bps": 50, **pm50}]).to_markdown(index=False, floatfmt=".4f") if not portfolio.empty else "No non-diagnostic rule survived into the strict portfolio.",
        "",
        "### Monthly block bootstrap at 30 bps",
        "",
        pd.DataFrame([boot]).to_markdown(index=False, floatfmt=".4f") if boot else "No bootstrap result.",
        "",
        "## Precision versus sample-size frontier",
        "",
        support_table.to_markdown(index=False, floatfmt=".4f") if not support_table.empty else "No frontier rows.",
        "",
        "## Strict A+ rules",
        "",
        pass_rows.head(30).to_markdown(index=False, floatfmt=".4f") if not pass_rows.empty else "None.",
        "",
        "## Observed 90% rules that failed the robustness gate",
        "",
        sparse_rows.head(30).to_markdown(index=False, floatfmt=".4f") if not sparse_rows.empty else "None.",
        "",
        "## Interpretation",
        "",
        "A target hit rate near 90% is accepted only when the sample, Wilson lower bound, annual stability, 50-bps expectancy and profit factor all pass. Otherwise the correct live label remains WAIT.",
        "",
        "## Progress",
        "",
        f"- Completed: {metadata['progress_completed_pct']}%",
        f"- Remaining: {metadata['progress_remaining_pct']}%",
        "",
        "The remaining work is a frozen-rule forward paper audit on genuinely future candles. Historical re-mining cannot substitute for that step.",
    ]
    (OUT / "phase5b_report.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    venues, status = p3.load_venues()
    required = {PRIMARY, SPOT}
    missing = required - set(venues)
    if missing:
        raise RuntimeError(f"Required venues missing: {sorted(missing)}")
    frames = build_frames(venues)
    events, _ = build_event_table(frames)
    outcomes = build_outcomes(events, frames[PRIMARY])
    merged = events.merge(outcomes, on=["event_id", "timeframe", "side", "signal_time"], how="inner")

    selected_parts = []
    audit_parts = []
    for fold in FOLDS:
        for tf, configs in CONFIGS.items():
            for side in ["long", "short"]:
                for cfg in configs:
                    selected, audit = select_rules_for_fold(merged, fold, tf, side, cfg["config_id"])
                    if not selected.empty:
                        selected_parts.append(selected)
                    if not audit.empty:
                        audit_parts.append(audit)
    selected = pd.concat(selected_parts, ignore_index=True) if selected_parts else pd.DataFrame()
    audit = pd.concat(audit_parts, ignore_index=True) if audit_parts else pd.DataFrame()
    portfolio = strict_portfolio(selected)
    frontier = precision_frontier(selected)
    gate = aplus_gate(frontier)
    support_table = support_precision_table(gate)

    events.to_csv(OUT / "perp_event_features.csv", index=False)
    outcomes.to_csv(OUT / "perp_event_outcomes.csv", index=False)
    audit.to_csv(OUT / "rule_mining_audit.csv", index=False)
    selected.to_csv(OUT / "walkforward_selected_test_events.csv", index=False)
    portfolio.to_csv(OUT / "strict_precision_portfolio.csv", index=False)
    frontier.to_csv(OUT / "rule_precision_frontier.csv", index=False)
    gate.to_csv(OUT / "aplus_gate.csv", index=False)
    support_table.to_csv(OUT / "support_precision_frontier.csv", index=False)
    pd.DataFrame(status).to_csv(OUT / "data_status.csv", index=False)

    aplus_count = int(gate.aplus_pass.sum()) if not gate.empty else 0
    metadata = {
        "phase": "5B",
        "generated_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "primary_venue": PRIMARY,
        "confirmation_venues": sorted(set(venues) - {PRIMARY}),
        "event_rows": int(len(events)),
        "outcome_rows": int(len(outcomes)),
        "candidate_audit_rows": int(len(audit)),
        "selected_test_rows": int(len(selected)),
        "strict_portfolio_rows": int(len(portfolio)),
        "aplus_rules": aplus_count,
        "sparse_observed_90_rules": int(gate.sparse_observed_90.sum()) if not gate.empty else 0,
        "progress_completed_pct": 95,
        "progress_remaining_pct": 5,
    }
    (OUT / "phase5b_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    write_report(metadata, portfolio, gate, support_table, audit)
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
