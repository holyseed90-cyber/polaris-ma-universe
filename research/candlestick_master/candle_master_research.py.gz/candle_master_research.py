from __future__ import annotations

import io
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import requests

DATA_URL = (
    "https://raw.githubusercontent.com/alessiostomeo/btc-cycle-data/main/"
    "binance/1h/BTCUSDT_binance_hourly_2018-2026.csv.gz"
)
START_DATE = "2018-01-01"
OUTPUT_DIR = Path(__file__).resolve().parent / "output"
MA_PERIODS = [5, 10, 20, 60, 112, 224, 448, 896]
TF_RULES = {"1h": "1h", "4h": "4h", "12h": "12h", "1d": "1D"}
TF_SECONDS = {"1h": 3600, "4h": 4 * 3600, "12h": 12 * 3600, "1d": 24 * 3600}
HORIZONS = {
    "1h": [1, 3, 6, 12, 24, 48, 72, 168],
    "4h": [1, 2, 3, 6, 12, 24, 42],
    "12h": [1, 2, 3, 6, 12, 14],
    "1d": [1, 2, 3, 7, 14, 30],
}
TRAIN_END = pd.Timestamp("2022-12-31 23:59:59", tz="UTC")
VALID_END = pd.Timestamp("2024-12-31 23:59:59", tz="UTC")
MIN_SAMPLE = 30


@dataclass(frozen=True)
class PatternMeta:
    name: str
    family: str
    direction: str
    source_label: str


PATTERN_META = {
    "pat_doji": PatternMeta("doji", "single", "neutral", "도지"),
    "pat_dragonfly_doji": PatternMeta("dragonfly_doji", "single", "bullish", "잠자리형 도지"),
    "pat_gravestone_doji": PatternMeta("gravestone_doji", "single", "bearish", "비석형 도지"),
    "pat_bull_marubozu": PatternMeta("bull_marubozu", "single", "bullish", "장대양봉"),
    "pat_bear_marubozu": PatternMeta("bear_marubozu", "single", "bearish", "장대음봉"),
    "pat_spinning_top": PatternMeta("spinning_top", "single", "neutral", "팽이형"),
    "pat_hammer": PatternMeta("hammer", "single", "bullish", "망치형"),
    "pat_hanging_man": PatternMeta("hanging_man", "single", "bearish", "교수형"),
    "pat_inverted_hammer": PatternMeta("inverted_hammer", "single", "bullish", "역망치형"),
    "pat_shooting_star": PatternMeta("shooting_star", "single", "bearish", "유성형"),
    "pat_bull_engulfing": PatternMeta("bull_engulfing", "two", "bullish", "상승 장악형"),
    "pat_bear_engulfing": PatternMeta("bear_engulfing", "two", "bearish", "하락 장악형"),
    "pat_bull_harami": PatternMeta("bull_harami", "two", "bullish", "상승 잉태형"),
    "pat_bear_harami": PatternMeta("bear_harami", "two", "bearish", "하락 잉태형"),
    "pat_piercing": PatternMeta("piercing", "two", "bullish", "상승 관통형"),
    "pat_dark_cloud": PatternMeta("dark_cloud", "two", "bearish", "흑운형"),
    "pat_bull_railroad": PatternMeta("bull_railroad", "two", "bullish", "상승 철길"),
    "pat_bear_railroad": PatternMeta("bear_railroad", "two", "bearish", "하락 철길"),
    "pat_tweezer_bottom": PatternMeta("tweezer_bottom", "two", "bullish", "트위저 바닥"),
    "pat_tweezer_top": PatternMeta("tweezer_top", "two", "bearish", "트위저 천장"),
    "pat_morning_star": PatternMeta("morning_star", "three", "bullish", "샛별형"),
    "pat_evening_star": PatternMeta("evening_star", "three", "bearish", "석별형"),
    "pat_three_white_soldiers": PatternMeta("three_white_soldiers", "three", "bullish", "적삼병"),
    "pat_three_black_crows": PatternMeta("three_black_crows", "three", "bearish", "흑삼병"),
    "pat_three_inside_up": PatternMeta("three_inside_up", "three", "bullish", "상승 잉태 확인형"),
    "pat_three_inside_down": PatternMeta("three_inside_down", "three", "bearish", "하락 잉태 확인형"),
    "pat_three_outside_up": PatternMeta("three_outside_up", "three", "bullish", "상승 장악 확인형"),
    "pat_three_outside_down": PatternMeta("three_outside_down", "three", "bearish", "하락 장악 확인형"),
    "pat_rising_three_methods": PatternMeta("rising_three_methods", "five", "bullish", "상승 삼법형"),
    "pat_falling_three_methods": PatternMeta("falling_three_methods", "five", "bearish", "하락 삼법형"),
    "pat_inside_bar": PatternMeta("inside_bar", "price_action", "neutral", "인사이드 바"),
    "pat_outside_bar_bull": PatternMeta("outside_bar_bull", "price_action", "bullish", "상승 아웃사이드 바"),
    "pat_outside_bar_bear": PatternMeta("outside_bar_bear", "price_action", "bearish", "하락 아웃사이드 바"),
    "pat_bull_sweep20": PatternMeta("bull_sweep20", "liquidity", "bullish", "20봉 저점 유동성 스윕"),
    "pat_bear_sweep20": PatternMeta("bear_sweep20", "liquidity", "bearish", "20봉 고점 유동성 스윕"),
    "pat_bull_breakout20": PatternMeta("bull_breakout20", "structure", "bullish", "20봉 고점 종가 돌파"),
    "pat_bear_breakdown20": PatternMeta("bear_breakdown20", "structure", "bearish", "20봉 저점 종가 이탈"),
    "pat_bull_rejection": PatternMeta("bull_rejection", "rejection", "bullish", "상승 리젝션"),
    "pat_bear_rejection": PatternMeta("bear_rejection", "rejection", "bearish", "하락 리젝션"),
}


def download_hourly() -> pd.DataFrame:
    response = requests.get(DATA_URL, timeout=180)
    response.raise_for_status()
    df = pd.read_csv(io.BytesIO(response.content), compression="gzip")
    df.columns = [str(c).strip().lower() for c in df.columns]
    date_col = next((c for c in ["datetime_utc", "date", "datetime", "timestamp"] if c in df.columns), None)
    if date_col is None:
        raise ValueError(f"No datetime column found: {df.columns.tolist()}")
    df[date_col] = pd.to_datetime(df[date_col], utc=True, errors="coerce")
    df = df.dropna(subset=[date_col]).set_index(date_col).sort_index()
    required = ["open", "high", "low", "close", "volume"]
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df[required].dropna()
    df = df.loc[df.index >= pd.Timestamp(START_DATE, tz="UTC")]
    df = df[~df.index.duplicated(keep="last")]
    return df


def resample_ohlcv(df: pd.DataFrame, rule: str) -> pd.DataFrame:
    if rule == "1h":
        return df.copy()
    out = df.resample(rule, label="left", closed="left", origin="epoch").agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        volume=("volume", "sum"),
    )
    return out.dropna(subset=["open", "high", "low", "close"])


def wilder_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(100).where(avg_gain.notna())


def wilder_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    prev_close = df["close"].shift(1)
    tr = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["rsi14"] = wilder_rsi(out["close"], 14)
    out["atr14"] = wilder_atr(out, 14)
    out["atr14_pct"] = out["atr14"] / out["close"] * 100
    for p in MA_PERIODS:
        out[f"ma{p}"] = out["close"].rolling(p, min_periods=p).mean()
        for lag in [3, 5, 10, 20, 30]:
            out[f"ma{p}_slope_{lag}"] = (out[f"ma{p}"] / out[f"ma{p}"].shift(lag) - 1) * 100
        out[f"price_vs_ma{p}_pct"] = (out["close"] / out[f"ma{p}"] - 1) * 100
        out[f"price_vs_ma{p}_atr"] = (out["close"] - out[f"ma{p}"]) / out["atr14"]
    for a, b in [(5, 10), (10, 20), (20, 60), (60, 112), (112, 224), (224, 448), (448, 896)]:
        out[f"gap_{a}_{b}_pct"] = (out[f"ma{a}"] / out[f"ma{b}"] - 1) * 100
        out[f"gap_{a}_{b}_chg5"] = out[f"gap_{a}_{b}_pct"] - out[f"gap_{a}_{b}_pct"].shift(5)
        out[f"gap_{a}_{b}_chg20"] = out[f"gap_{a}_{b}_pct"] - out[f"gap_{a}_{b}_pct"].shift(20)
    ma_cols = [f"ma{p}" for p in MA_PERIODS]
    out["ma_spread_all_pct"] = (out[ma_cols].max(axis=1) / out[ma_cols].min(axis=1) - 1) * 100
    long_cols = ["ma224", "ma448", "ma896"]
    out["ma_spread_long_pct"] = (out[long_cols].max(axis=1) / out[long_cols].min(axis=1) - 1) * 100
    out["price_above_ma_count"] = sum((out["close"] > out[f"ma{p}"]).astype(int) for p in MA_PERIODS)
    out["ma_rising20_count"] = sum((out[f"ma{p}_slope_20"] > 0).astype(int) for p in MA_PERIODS)
    out["full_bull_stack"] = np.logical_and.reduce([out[f"ma{a}"] > out[f"ma{b}"] for a, b in zip(MA_PERIODS[:-1], MA_PERIODS[1:])])
    out["full_bear_stack"] = np.logical_and.reduce([out[f"ma{a}"] < out[f"ma{b}"] for a, b in zip(MA_PERIODS[:-1], MA_PERIODS[1:])])
    return out


def add_candle_geometry(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    eps = 1e-12
    out["range"] = (out["high"] - out["low"]).clip(lower=eps)
    out["body_signed"] = out["close"] - out["open"]
    out["body"] = out["body_signed"].abs()
    out["bull"] = out["close"] > out["open"]
    out["bear"] = out["close"] < out["open"]
    out["body_ratio"] = out["body"] / out["range"]
    out["upper_wick"] = out["high"] - out[["open", "close"]].max(axis=1)
    out["lower_wick"] = out[["open", "close"]].min(axis=1) - out["low"]
    out["upper_wick_ratio"] = out["upper_wick"] / out["range"]
    out["lower_wick_ratio"] = out["lower_wick"] / out["range"]
    out["close_location"] = (out["close"] - out["low"]) / out["range"]
    out["open_location"] = (out["open"] - out["low"]) / out["range"]
    out["range_atr"] = out["range"] / out["atr14"]
    out["body_atr"] = out["body"] / out["atr14"]
    out["ret_pct"] = out["close"].pct_change() * 100
    out["gap_pct"] = (out["open"] / out["close"].shift(1) - 1) * 100
    out["range_percentile_100"] = out["range_atr"].rolling(100, min_periods=30).rank(pct=True)
    out["body_percentile_100"] = out["body_atr"].rolling(100, min_periods=30).rank(pct=True)
    return out


def add_patterns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    br = out["body_ratio"]
    uwr = out["upper_wick_ratio"]
    lwr = out["lower_wick_ratio"]
    bull = out["bull"]
    bear = out["bear"]
    body = out["body"]
    body_hi = out[["open", "close"]].max(axis=1)
    body_lo = out[["open", "close"]].min(axis=1)
    prev_body_hi = body_hi.shift(1)
    prev_body_lo = body_lo.shift(1)
    prev_body = body.shift(1)
    prev_bull = bull.shift(1).fillna(False).astype(bool)
    prev_bear = bear.shift(1).fillna(False).astype(bool)

    out["pat_doji"] = br <= 0.10
    out["pat_dragonfly_doji"] = (br <= 0.12) & (lwr >= 0.60) & (uwr <= 0.12)
    out["pat_gravestone_doji"] = (br <= 0.12) & (uwr >= 0.60) & (lwr <= 0.12)
    out["pat_bull_marubozu"] = bull & (br >= 0.78) & (uwr <= 0.12) & (lwr <= 0.12)
    out["pat_bear_marubozu"] = bear & (br >= 0.78) & (uwr <= 0.12) & (lwr <= 0.12)
    out["pat_spinning_top"] = (br <= 0.30) & (uwr >= 0.20) & (lwr >= 0.20)

    lower_dominant = (out["lower_wick"] >= 2.0 * body.clip(lower=1e-12)) & (uwr <= 0.20)
    upper_dominant = (out["upper_wick"] >= 2.0 * body.clip(lower=1e-12)) & (lwr <= 0.20)
    prior_down = out["close"].shift(1) < out["close"].shift(5)
    prior_up = out["close"].shift(1) > out["close"].shift(5)
    out["pat_hammer"] = lower_dominant & prior_down & (out["close_location"] >= 0.60)
    out["pat_hanging_man"] = lower_dominant & prior_up
    out["pat_inverted_hammer"] = upper_dominant & prior_down
    out["pat_shooting_star"] = upper_dominant & prior_up & (out["close_location"] <= 0.40)

    out["pat_bull_engulfing"] = prev_bear & bull & (body_lo <= prev_body_lo) & (body_hi >= prev_body_hi) & (body >= prev_body * 0.9)
    out["pat_bear_engulfing"] = prev_bull & bear & (body_hi >= prev_body_hi) & (body_lo <= prev_body_lo) & (body >= prev_body * 0.9)
    out["pat_bull_harami"] = prev_bear & bull & (body_hi <= prev_body_hi) & (body_lo >= prev_body_lo) & (body <= prev_body * 0.75)
    out["pat_bear_harami"] = prev_bull & bear & (body_hi <= prev_body_hi) & (body_lo >= prev_body_lo) & (body <= prev_body * 0.75)
    prev_mid = (out["open"].shift(1) + out["close"].shift(1)) / 2
    out["pat_piercing"] = prev_bear & bull & (out["open"] <= out["close"].shift(1)) & (out["close"] > prev_mid) & (out["close"] < out["open"].shift(1))
    out["pat_dark_cloud"] = prev_bull & bear & (out["open"] >= out["close"].shift(1)) & (out["close"] < prev_mid) & (out["close"] > out["open"].shift(1))

    similar_body = (body / prev_body.replace(0, np.nan)).between(0.70, 1.40)
    overlap = (np.minimum(body_hi, prev_body_hi) - np.maximum(body_lo, prev_body_lo)).clip(lower=0)
    overlap_ratio = overlap / np.minimum(body, prev_body).replace(0, np.nan)
    out["pat_bull_railroad"] = prev_bear & bull & similar_body & (overlap_ratio >= 0.65)
    out["pat_bear_railroad"] = prev_bull & bear & similar_body & (overlap_ratio >= 0.65)
    tol = out["atr14"] * 0.10
    out["pat_tweezer_bottom"] = prev_bear & bull & ((out["low"] - out["low"].shift(1)).abs() <= tol) & (body >= prev_body * 0.50)
    out["pat_tweezer_top"] = prev_bull & bear & ((out["high"] - out["high"].shift(1)).abs() <= tol) & (body >= prev_body * 0.50)

    # Three-candle formations. Crypto has few true gaps, so the middle candle is judged by body compression and location.
    c1_bear = bear.shift(2).fillna(False).astype(bool)
    c1_bull = bull.shift(2).fillna(False).astype(bool)
    c1_body = body.shift(2)
    c1_mid = (out["open"].shift(2) + out["close"].shift(2)) / 2
    c2_small = body.shift(1) <= c1_body * 0.40
    out["pat_morning_star"] = c1_bear & c2_small & bull & (out["close"] >= c1_mid) & (body >= c1_body * 0.50)
    out["pat_evening_star"] = c1_bull & c2_small & bear & (out["close"] <= c1_mid) & (body >= c1_body * 0.50)

    consecutive_bull = bull & bull.shift(1).fillna(False).astype(bool) & bull.shift(2).fillna(False).astype(bool)
    consecutive_bear = bear & bear.shift(1).fillna(False).astype(bool) & bear.shift(2).fillna(False).astype(bool)
    out["pat_three_white_soldiers"] = consecutive_bull & (out["close"] > out["close"].shift(1)) & (out["close"].shift(1) > out["close"].shift(2)) & (br > 0.45) & (br.shift(1) > 0.45) & (br.shift(2) > 0.45)
    out["pat_three_black_crows"] = consecutive_bear & (out["close"] < out["close"].shift(1)) & (out["close"].shift(1) < out["close"].shift(2)) & (br > 0.45) & (br.shift(1) > 0.45) & (br.shift(2) > 0.45)
    out["pat_three_inside_up"] = out["pat_bull_harami"].shift(1).fillna(False).astype(bool) & bull & (out["close"] > out["high"].shift(2))
    out["pat_three_inside_down"] = out["pat_bear_harami"].shift(1).fillna(False).astype(bool) & bear & (out["close"] < out["low"].shift(2))
    out["pat_three_outside_up"] = out["pat_bull_engulfing"].shift(1).fillna(False).astype(bool) & bull & (out["close"] > out["close"].shift(1))
    out["pat_three_outside_down"] = out["pat_bear_engulfing"].shift(1).fillna(False).astype(bool) & bear & (out["close"] < out["close"].shift(1))

    first_bull = bull.shift(4).fillna(False).astype(bool) & (br.shift(4) >= 0.55)
    first_bear = bear.shift(4).fillna(False).astype(bool) & (br.shift(4) >= 0.55)
    middle_inside_bull = np.logical_and.reduce([
        out["high"].shift(k) < out["high"].shift(4) for k in [1, 2, 3]
    ]) & np.logical_and.reduce([
        out["low"].shift(k) > out["low"].shift(4) for k in [1, 2, 3]
    ])
    out["pat_rising_three_methods"] = first_bull & middle_inside_bull & bull & (out["close"] > out["high"].shift(4))
    out["pat_falling_three_methods"] = first_bear & middle_inside_bull & bear & (out["close"] < out["low"].shift(4))

    out["pat_inside_bar"] = (out["high"] < out["high"].shift(1)) & (out["low"] > out["low"].shift(1))
    outside = (out["high"] > out["high"].shift(1)) & (out["low"] < out["low"].shift(1))
    out["pat_outside_bar_bull"] = outside & bull & (out["close_location"] >= 0.70)
    out["pat_outside_bar_bear"] = outside & bear & (out["close_location"] <= 0.30)

    prev_high20 = out["high"].shift(1).rolling(20, min_periods=20).max()
    prev_low20 = out["low"].shift(1).rolling(20, min_periods=20).min()
    out["pat_bull_sweep20"] = (out["low"] < prev_low20) & (out["close"] > prev_low20) & (out["close_location"] >= 0.55)
    out["pat_bear_sweep20"] = (out["high"] > prev_high20) & (out["close"] < prev_high20) & (out["close_location"] <= 0.45)
    out["pat_bull_breakout20"] = out["close"] > prev_high20
    out["pat_bear_breakdown20"] = out["close"] < prev_low20
    out["pat_bull_rejection"] = (lwr >= 0.55) & (out["close_location"] >= 0.70) & (out["range_atr"] >= 0.75)
    out["pat_bear_rejection"] = (uwr >= 0.55) & (out["close_location"] <= 0.30) & (out["range_atr"] >= 0.75)

    for col in PATTERN_META:
        out[col] = out[col].fillna(False).astype(bool)
    return out


def add_context(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    out = df.copy()
    out["trend_regime"] = np.select(
        [
            out["full_bull_stack"],
            out["full_bear_stack"],
            (out["price_above_ma_count"] >= 7) & (out["ma_rising20_count"] >= 6),
            (out["price_above_ma_count"] <= 1) & (out["ma_rising20_count"] <= 2),
        ],
        ["full_bull_stack", "full_bear_stack", "broad_bull", "broad_bear"],
        default="mixed",
    )
    out["ma_location"] = pd.cut(
        out["price_above_ma_count"],
        bins=[-1, 1, 3, 5, 7, 8],
        labels=["below_0_1", "below_2_3", "middle_4_5", "above_6_7", "above_all"],
    ).astype("string")
    out["rsi_bucket"] = pd.cut(
        out["rsi14"],
        bins=[-np.inf, 30, 40, 50, 60, 70, np.inf],
        labels=["lt30", "30_40", "40_50", "50_60", "60_70", "ge70"],
        right=False,
    ).astype("string")
    out["atr_bucket"] = pd.cut(
        out["atr14_pct"],
        bins=[-np.inf, 2, 3, 4, 5, 6, np.inf],
        labels=["lt2", "2_3", "3_4", "4_5", "5_6", "ge6"],
        right=False,
    ).astype("string")
    out["long_ma_state"] = np.select(
        [
            (out["ma224"] > out["ma448"]) & (out["ma448"] > out["ma896"]),
            (out["ma224"] < out["ma448"]) & (out["ma448"] < out["ma896"]),
            (out["ma224_slope_20"] > 0) & (out["ma448_slope_20"] < 0),
        ],
        ["long_bull_stack", "long_bear_stack", "224_up_448_down"],
        default="long_mixed",
    )
    if timeframe == "1h":
        hour = out.index.hour
        out["session_utc"] = np.select(
            [hour < 8, (hour >= 8) & (hour < 16), hour >= 16],
            ["asia", "london", "new_york"],
            default="unknown",
        )
    else:
        out["session_utc"] = "all"
    return out


def forward_window_max(series: pd.Series, horizon: int) -> pd.Series:
    return series.shift(-1).rolling(horizon, min_periods=horizon).max().shift(-(horizon - 1))


def forward_window_min(series: pd.Series, horizon: int) -> pd.Series:
    return series.shift(-1).rolling(horizon, min_periods=horizon).min().shift(-(horizon - 1))


def add_outcomes(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    out = df.copy()
    for h in HORIZONS[timeframe]:
        out[f"fwd_ret_{h}"] = (out["close"].shift(-h) / out["close"] - 1) * 100
        fmax = forward_window_max(out["high"], h)
        fmin = forward_window_min(out["low"], h)
        out[f"mfe_{h}_pct"] = (fmax / out["close"] - 1) * 100
        out[f"mae_{h}_pct"] = (fmin / out["close"] - 1) * 100
        out[f"mfe_{h}_atr"] = (fmax - out["close"]) / out["atr14"]
        out[f"mae_{h}_atr"] = (fmin - out["close"]) / out["atr14"]
    return out


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (math.nan, math.nan)
    p = successes / n
    denom = 1 + z**2 / n
    center = (p + z**2 / (2 * n)) / denom
    margin = z * math.sqrt((p * (1 - p) + z**2 / (4 * n)) / n) / denom
    return center - margin, center + margin


def split_name(index: pd.DatetimeIndex) -> pd.Series:
    return pd.Series(
        np.where(index <= TRAIN_END, "train", np.where(index <= VALID_END, "validation", "test")),
        index=index,
        dtype="string",
    )


def summarize_group(g: pd.DataFrame, timeframe: str, pattern_col: str, split: str, context: str = "all") -> dict:
    meta = PATTERN_META[pattern_col]
    row: dict[str, object] = {
        "timeframe": timeframe,
        "pattern": meta.name,
        "source_label": meta.source_label,
        "family": meta.family,
        "direction": meta.direction,
        "split": split,
        "context": context,
        "n": int(len(g)),
    }
    for h in HORIZONS[timeframe]:
        vals = g[f"fwd_ret_{h}"].dropna()
        if vals.empty:
            continue
        positive = int((vals > 0).sum())
        low, high = wilson_interval(positive, len(vals))
        row[f"ret_{h}_mean"] = float(vals.mean())
        row[f"ret_{h}_median"] = float(vals.median())
        row[f"ret_{h}_positive_rate"] = float(positive / len(vals))
        row[f"ret_{h}_positive_ci_low"] = float(low)
        row[f"ret_{h}_positive_ci_high"] = float(high)
        row[f"mfe_{h}_median_pct"] = float(g[f"mfe_{h}_pct"].median())
        row[f"mae_{h}_median_pct"] = float(g[f"mae_{h}_pct"].median())
        row[f"mfe_{h}_median_atr"] = float(g[f"mfe_{h}_atr"].median())
        row[f"mae_{h}_median_atr"] = float(g[f"mae_{h}_atr"].median())
    return row


def pattern_performance(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    work = df.copy()
    work["split"] = split_name(work.index)
    rows: list[dict] = []
    for pattern_col in PATTERN_META:
        hits = work[work[pattern_col]]
        if hits.empty:
            continue
        rows.append(summarize_group(hits, timeframe, pattern_col, "all"))
        for split in ["train", "validation", "test"]:
            g = hits[hits["split"] == split]
            if not g.empty:
                rows.append(summarize_group(g, timeframe, pattern_col, split))
    return pd.DataFrame(rows)


def context_performance(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
    work = df.copy()
    work["split"] = split_name(work.index)
    rows: list[dict] = []
    context_specs = [
        ["trend_regime"],
        ["ma_location"],
        ["long_ma_state"],
        ["rsi_bucket"],
        ["atr_bucket"],
        ["trend_regime", "rsi_bucket"],
        ["trend_regime", "atr_bucket"],
        ["ma_location", "rsi_bucket"],
    ]
    if timeframe == "1h":
        context_specs.append(["session_utc"])
        context_specs.append(["session_utc", "trend_regime"])
    for pattern_col in PATTERN_META:
        hits = work[work[pattern_col]]
        if hits.empty:
            continue
        for cols in context_specs:
            grouped = hits.groupby(cols, observed=True, dropna=False)
            for keys, g in grouped:
                if len(g) < MIN_SAMPLE:
                    continue
                if not isinstance(keys, tuple):
                    keys = (keys,)
                context = ";".join(f"{c}={k}" for c, k in zip(cols, keys))
                rows.append(summarize_group(g, timeframe, pattern_col, "all", context))
                for split in ["train", "validation", "test"]:
                    gs = g[g["split"] == split]
                    if len(gs) >= max(10, MIN_SAMPLE // 3):
                        rows.append(summarize_group(gs, timeframe, pattern_col, split, context))
    return pd.DataFrame(rows)


def add_available_higher_context(base_1h: pd.DataFrame, higher: dict[str, pd.DataFrame]) -> pd.DataFrame:
    result = base_1h.copy().reset_index().rename(columns={base_1h.index.name or "index": "timestamp"})
    result = result.sort_values("timestamp")
    for tf in ["4h", "12h", "1d"]:
        h = higher[tf].copy()
        availability = h.index + pd.to_timedelta(TF_SECONDS[tf], unit="s")
        ctx = pd.DataFrame(
            {
                "timestamp": availability,
                f"{tf}_trend_regime": h["trend_regime"].to_numpy(),
                f"{tf}_ma_location": h["ma_location"].astype("string").to_numpy(),
                f"{tf}_rsi_bucket": h["rsi_bucket"].astype("string").to_numpy(),
                f"{tf}_long_ma_state": h["long_ma_state"].to_numpy(),
                f"{tf}_close_vs_ma20": h["price_vs_ma20_pct"].to_numpy(),
                f"{tf}_close_vs_ma60": h["price_vs_ma60_pct"].to_numpy(),
                f"{tf}_close_vs_ma112": h["price_vs_ma112_pct"].to_numpy(),
            }
        ).sort_values("timestamp")
        result = pd.merge_asof(result, ctx, on="timestamp", direction="backward")
    return result.set_index("timestamp")


def mtf_performance(merged_1h: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    work = merged_1h.copy()
    work["split"] = split_name(work.index)
    for pattern_col, meta in PATTERN_META.items():
        hits = work[work[pattern_col]]
        if hits.empty:
            continue
        for tf in ["4h", "12h", "1d"]:
            col = f"{tf}_trend_regime"
            if col not in hits:
                continue
            for regime, g in hits.groupby(col, observed=True, dropna=False):
                if len(g) < MIN_SAMPLE:
                    continue
                row = summarize_group(g, "1h", pattern_col, "all", f"higher_tf={tf};regime={regime}")
                rows.append(row)
    return pd.DataFrame(rows)


def data_quality_report(hourly: pd.DataFrame, frames: dict[str, pd.DataFrame]) -> dict:
    expected = pd.date_range(hourly.index.min(), hourly.index.max(), freq="1h", tz="UTC")
    missing = expected.difference(hourly.index)
    return {
        "source_url": DATA_URL,
        "raw_start": hourly.index.min().isoformat(),
        "raw_end": hourly.index.max().isoformat(),
        "raw_rows": int(len(hourly)),
        "duplicate_timestamps": int(hourly.index.duplicated().sum()),
        "missing_hour_count": int(len(missing)),
        "missing_hour_examples": [x.isoformat() for x in missing[:50]],
        "frame_rows": {tf: int(len(df)) for tf, df in frames.items()},
        "timezone": "UTC",
        "resampling": "UTC epoch-aligned, left-closed and left-labeled",
    }


def select_top_patterns(perf: pd.DataFrame) -> pd.DataFrame:
    if perf.empty:
        return perf
    # Focus on the longest available primary swing horizon per timeframe, penalizing tiny samples.
    rows = []
    for _, r in perf[perf["split"] == "test"].iterrows():
        tf = r["timeframe"]
        h = HORIZONS[tf][-2] if len(HORIZONS[tf]) >= 2 else HORIZONS[tf][-1]
        med = r.get(f"ret_{h}_median", np.nan)
        rate = r.get(f"ret_{h}_positive_rate", np.nan)
        n = r.get("n", 0)
        if pd.isna(med) or pd.isna(rate) or n < 10:
            continue
        direction = r["direction"]
        signed_edge = med if direction != "bearish" else -med
        directional_rate = rate if direction != "bearish" else 1 - rate
        score = signed_edge * math.sqrt(n) * max(directional_rate - 0.5, 0)
        rows.append({**r.to_dict(), "ranking_horizon": h, "edge_score": score})
    return pd.DataFrame(rows).sort_values("edge_score", ascending=False)


def make_markdown_report(
    quality: dict,
    perf: pd.DataFrame,
    context_perf: pd.DataFrame,
    mtf_perf: pd.DataFrame,
) -> str:
    top = select_top_patterns(perf)
    lines = [
        "# BTC Candlestick Master Research — Phase 1",
        "",
        "## Scope",
        "",
        f"- Source: Binance BTCUSDT hourly OHLCV",
        f"- Period: {quality['raw_start']} → {quality['raw_end']}",
        f"- Raw 1h bars: {quality['raw_rows']:,}",
        "- Reconstructed timeframes: 1h, 4h, 12h, 1d",
        "- Signals use only information available at candle close; higher-timeframe context becomes available only after that higher-timeframe candle closes.",
        "- Split: 2018–2022 train, 2023–2024 validation, 2025–present untouched test.",
        "",
        "## Pattern language",
        "",
        "Traditional candlestick names are treated as labels, not truths. Each pattern is encoded from body/range/wick geometry and then tested by location, market regime, RSI, ATR, session, and higher-timeframe context.",
        "",
        "## Data quality",
        "",
        f"- Missing hourly timestamps: {quality['missing_hour_count']}",
        f"- Duplicate timestamps: {quality['duplicate_timestamps']}",
        "",
        "## Top out-of-sample candidates",
        "",
    ]
    if top.empty:
        lines.append("No pattern passed the current minimum sample and test criteria.")
    else:
        cols = ["timeframe", "source_label", "direction", "n", "ranking_horizon", "edge_score"]
        lines.append(top[cols].head(25).to_markdown(index=False, floatfmt=".3f"))
    lines.extend(
        [
            "",
            "## Interpretation rules",
            "",
            "1. A pattern is not promoted unless it survives validation and test periods.",
            "2. Location is evaluated independently: moving-average regime, RSI, ATR, liquidity sweep, and higher-timeframe direction.",
            "3. Overlapping candles are not treated as independent proof; final inference must use event de-duplication and bootstrap confidence intervals in Phase 2.",
            "4. Future work: wave-touch detection, sequence mining (2–8 candles), first-passage target/stop ordering, cluster-based analog search, and non-repainting TradingView rules.",
            "",
            "## Generated files",
            "",
            "- `pattern_performance.csv`: base pattern performance by timeframe and time split",
            "- `pattern_context_performance.csv`: pattern × location/regime/RSI/ATR/session",
            "- `mtf_pattern_performance.csv`: 1h patterns conditioned on completed 4h/12h/1d regimes",
            "- `latest_state.json`: latest complete multi-timeframe candle state",
            "- `data_quality.json`: source continuity and resampling metadata",
        ]
    )
    return "\n".join(lines)


def latest_state(frames: dict[str, pd.DataFrame]) -> dict:
    result = {}
    keep = [
        "open", "high", "low", "close", "volume", "rsi14", "atr14_pct",
        "body_ratio", "upper_wick_ratio", "lower_wick_ratio", "close_location",
        "trend_regime", "ma_location", "long_ma_state", "price_above_ma_count", "ma_rising20_count",
    ]
    keep += [f"ma{p}" for p in MA_PERIODS]
    keep += [f"ma{p}_slope_20" for p in MA_PERIODS]
    for tf, df in frames.items():
        row = df.dropna(subset=["ma896"]).iloc[-1]
        patterns = [PATTERN_META[c].name for c in PATTERN_META if bool(row[c])]
        values = {}
        for col in keep:
            value = row.get(col)
            if pd.isna(value):
                values[col] = None
            elif isinstance(value, (np.floating, float, np.integer, int)):
                values[col] = float(value)
            else:
                values[col] = str(value)
        result[tf] = {"timestamp": row.name.isoformat(), "patterns": patterns, **values}
    return result


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    hourly = download_hourly()
    frames: dict[str, pd.DataFrame] = {}
    base_frames: dict[str, pd.DataFrame] = {}
    perf_parts = []
    context_parts = []

    for tf, rule in TF_RULES.items():
        frame = resample_ohlcv(hourly, rule)
        frame = add_indicators(frame)
        frame = add_candle_geometry(frame)
        frame = add_patterns(frame)
        frame = add_context(frame, tf)
        frame = add_outcomes(frame, tf)
        frames[tf] = frame
        base_frames[tf] = frame
        perf_parts.append(pattern_performance(frame, tf))
        context_parts.append(context_performance(frame, tf))

    merged_1h = add_available_higher_context(frames["1h"], frames)
    mtf = mtf_performance(merged_1h)
    perf = pd.concat(perf_parts, ignore_index=True)
    context = pd.concat(context_parts, ignore_index=True)
    quality = data_quality_report(hourly, base_frames)

    perf.to_csv(OUTPUT_DIR / "pattern_performance.csv", index=False)
    context.to_csv(OUTPUT_DIR / "pattern_context_performance.csv", index=False)
    mtf.to_csv(OUTPUT_DIR / "mtf_pattern_performance.csv", index=False)
    with (OUTPUT_DIR / "data_quality.json").open("w", encoding="utf-8") as f:
        json.dump(quality, f, ensure_ascii=False, indent=2)
    with (OUTPUT_DIR / "latest_state.json").open("w", encoding="utf-8") as f:
        json.dump(latest_state(frames), f, ensure_ascii=False, indent=2)
    with (OUTPUT_DIR / "pattern_dictionary.json").open("w", encoding="utf-8") as f:
        json.dump(
            {k: {"name": v.name, "family": v.family, "direction": v.direction, "source_label": v.source_label} for k, v in PATTERN_META.items()},
            f,
            ensure_ascii=False,
            indent=2,
        )
    report = make_markdown_report(quality, perf, context, mtf)
    (OUTPUT_DIR / "research_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
